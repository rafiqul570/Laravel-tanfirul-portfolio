<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(route('homePage')); ?>">My Portfolio</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a href="<?php echo e(route('homePage')); ?>" class="nav-link text-light">Home</a></li>
        <li class="nav-item"><a href="#about" class="nav-link text-light">About</a></li>
        <li class="nav-item"><a href="#projects" class="nav-link text-light">Projects</a></li>
        <li class="nav-item"><a href="#contact" class="nav-link text-light">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/pages/inc/navbar.blade.php ENDPATH**/ ?>