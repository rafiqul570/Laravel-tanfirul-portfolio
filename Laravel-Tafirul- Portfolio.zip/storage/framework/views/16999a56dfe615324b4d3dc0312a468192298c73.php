
<?php
  $patient = App\Models\Appointment::latest()->get();         
?>


<?php $__env->startSection('content'); ?>

 <div class="card pd-20 pd-sm-40">
        <h6 class="card-body-title">Patient Details</h6>
        <p class="mg-b-20 mg-sm-b-30">Get expert advice from professionals anytime, anywhere.</p>

          <div class="table-wrapper">
            <table id="datatable" class="table table-striped" style="width:100%">
              <thead>
                <tr>
                  <th class="wd-15p">Patient ID</th>
                  <th class="wd-15p">Patient name</th>
                  <th class="wd-15p">Phone number</th>
                  <th class="wd-10p">Department</th>
                  <th class="wd-15p">Doctor</th>
                  <th class="wd-10p">Date</th>
                  <th class="wd-10p">Time</th>
                  <th class="wd-10p">Action</th>
                </tr>
              </thead>
              
              <tbody>
              	<?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($data->id); ?></td>
                  <td><?php echo e($data->name); ?></td>
                  <td><?php echo e($data->phone); ?></td>
                  <td><?php echo e($data->department); ?></td>
                  <td><?php echo e($data->doctor); ?></td>
                  <td><?php echo e($data->date); ?></td>
                  <td><?php echo e($data->time); ?></td>
                  <td>
                  	<a class="btn btn-primary" href="<?php echo e(route('appointment.delete', $data->id)); ?>">Delete</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->

      <?php $__env->stopSection(); ?>



       






      

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-appointment\resources\views/appointment/index.blade.php ENDPATH**/ ?>