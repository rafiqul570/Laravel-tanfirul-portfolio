
  <?php echo $__env->make('admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div class="sl-mainpanel">
       <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="<?php echo e(route('redirects')); ?>">Dashboard</a>
        <a class="" href="index.html"></a>
        <span class=""></span>
      </nav>
      <div class="sl-pagebody">
       
           
           <?php echo $__env->yieldContent('content'); ?>
       
    
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
     <?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/admin/layouts/template.blade.php ENDPATH**/ ?>