<?php      
  $allDoctor = App\Models\Doctor::latest()->get();   
  $allCategory = App\Models\Category::latest()->get();   
?>

<?php echo $__env->make('pages.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <span class="text-white">All Doctors</span>
          <h1 class="text-capitalize mb-5 text-lg">Specalized doctors</h1>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- portfolio -->
<section class="section doctors">
   <?php echo $__env->make('pages.inc.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container">
    <div class="row">
      <?php if($doctor->isEmpty()): ?>
              
      <h2 class="mt-5">Doctor Not Found....</h2>
      
      <?php else: ?>

    	<?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-3 col-sm-6 col-md-6 my-5">
        	<div class="position-relative doctor-inner-box">
		        <div class="doctor-profile">
		        	<div class="doctor-img">
		               <a href="<?php echo e(route('pages.doctorSingle', [$data->id, $data->slug])); ?>"><img src="<?php echo e(asset('/uploads/image/'.$data->post_img)); ?>" class="img-fluid w-100"></a>
		             </div>
	             </div>
                <div class="content mt-3">
                	<h4 class="mb-0"><a href="<?php echo e(route('pages.doctorSingle', [$data->id, $data->slug])); ?>"><?php echo e(Str::limit($data->title, 30)); ?></a></h4>
                	<p><?php echo e(Str::limit($data->category_name, 15)); ?></p>
              </div> 
	      	</div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
  </div>
</section>
<!-- /portfolio -->
<section class="section cta-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-7">
				<div class="cta-content">
					<div class="divider mb-4"></div>
					<h2 class="mb-5 text-lg">We are pleased to offer you the <span class="title-color">chance to have the healthy</span></h2>
					<a href="<?php echo e(route('appointment.create')); ?>" class="btn btn-main-2 btn-round-full">Get appoinment<i class="icofont-simple-right  ml-2"></i></a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php echo $__env->make('pages.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-appointment\resources\views/pages/categoryPage.blade.php ENDPATH**/ ?>