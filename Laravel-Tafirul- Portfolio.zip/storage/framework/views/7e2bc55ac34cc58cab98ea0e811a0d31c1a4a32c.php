
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Create Post</h2>
    <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
        	<label class="">Category</label>
              <select class="form-control select2" name="category_id" data-placeholder="Choose one"
              data-parsley-class-handler="#slWrapper"
              data-parsley-errors-container="#slErrorContainer" required>
              <option selected="" disabled="">Select Category</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>

        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label>Short Description</label>
            <textarea name="short_description" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label>Link Name</label>
            <input type="text" name="link_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Post Image</label>
            <input type="file" name="post_image" class="form-control">
        </div>
        <button class="btn btn-primary" style="cursor: pointer;">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/post/create.blade.php ENDPATH**/ ?>