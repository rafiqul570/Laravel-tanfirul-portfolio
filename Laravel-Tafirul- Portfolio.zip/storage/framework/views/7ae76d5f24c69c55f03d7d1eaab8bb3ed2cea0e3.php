

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('appointment.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-appointment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>