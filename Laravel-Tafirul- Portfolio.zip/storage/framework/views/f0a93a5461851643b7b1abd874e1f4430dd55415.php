<!-- Hero Section -->
  <section class="hero" id="home" data-aos="fade-down">
    <div class="container">
      <h1 class="display-4">Hi, I'm Rafiqul Islam</h1>
      <p class="lead">Laravel Backend Developer | WordPress Expert</p>
       <a href="#projects" class="btn btn-primary mt-3" data-aos="zoom-in" data-aos-delay="200">View My Work</a>
    </div>
  </section><?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/pages/inc/hero.blade.php ENDPATH**/ ?>