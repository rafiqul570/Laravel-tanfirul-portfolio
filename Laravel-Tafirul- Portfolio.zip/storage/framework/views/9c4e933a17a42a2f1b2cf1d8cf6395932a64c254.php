<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Rafiqul Islam | Portfolio</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'arial', Segoe UI, sans-serif;
      scroll-behavior: smooth;
      padding-top: 50px;
      background: linear-gradient(135deg, #4c83ff, #a26bff);
      color: white;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .hero {
      background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('<?php echo e(asset("frontend/image/hero.jpg")); ?>') center/cover no-repeat;
      color: white;
      padding: 150px 0;
      text-align: center;
    }
    
    .section-title {
      font-weight: bold;
      margin-bottom: 40px;
    }
    .project-card img {
      height: 200px;
      object-fit: cover;
    }
    footer {
      background: #212529;
      color: white;
      padding: 20px 0;
    }

    a{
    text-decoration: none;
    color: #000000;
    font-size: 20px;
    font-weight: 500;
    padding: 0px 10px;
  }

  .countdown {
      font-size: 2rem;
      margin-top: 20px;
    }
    .countdown span {
      display: inline-block;
      min-width: 70px;
    }
  </style>
  
</head>
<body>


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(route('homePage')); ?>">My Portfolio</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a href="<?php echo e(route('homePage')); ?>" class="nav-link text-light"></a></li>
        <li class="nav-item"><a href="#about" class="nav-link text-light"></a></li>
        <li class="nav-item"><a href="#projects" class="nav-link text-light"></a></li>
        <li class="nav-item"><a href="#contact" class="nav-link text-light"></a></li>
      </ul>
    </div>
  </div>
</nav>


  <div class="container">
    <h1 class="display-3 fw-bold">Coming Soon</h1>
    <p class="lead">We are launching our website very soon. Stay tuned!</p>
    <div class="countdown" id="countdown">
      <span id="days">00</span> Days 
      <span id="hours">00</span> Hours 
      <span id="minutes">00</span> Min 
      <span id="seconds">00</span> Sec
    </div>
  </div>

  <script>
    const launchDate = new Date("2025-08-01T00:00:00").getTime();

    const countdown = () => {
      const now = new Date().getTime();
      const diff = launchDate - now;

      if (diff <= 0) {
        document.getElementById("countdown").innerHTML = "We are live!";
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      document.getElementById("days").innerText = String(days).padStart(2, '0');
      document.getElementById("hours").innerText = String(hours).padStart(2, '0');
      document.getElementById("minutes").innerText = String(minutes).padStart(2, '0');
      document.getElementById("seconds").innerText = String(seconds).padStart(2, '0');
    };

    setInterval(countdown, 1000);
  </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/pages/wordpress.blade.php ENDPATH**/ ?>