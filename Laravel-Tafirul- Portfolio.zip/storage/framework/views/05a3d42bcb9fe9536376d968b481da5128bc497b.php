<!-- About Section -->
  <section class="py-5" id="about">
    <div class="container" data-aos="fade-up">
      <h2 class="text-center mb-5">About Me</h2>
      <div class="row align-items-center">
        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="zoom-in">
          <img src="<?php echo e(asset('frontend/image/rafiqul.png')); ?>" alt="Rafiqul Islam" class="img-fluid rounded-circle shadow">
        </div>
        <div class="col-md-7" data-aos="fade-left">
          <h3>Hello! I'm Rafiqul Islam</h3>
          <p>I am a passionate Laravel backend developer and WordPress expert with over 3 years of experience in building web applications, eCommerce platforms, and custom CMS solutions. I love transforming complex problems into clean, efficient, and intuitive solutions.</p>
          <ul class="list-unstyled">
            My Skills:
            <li><i class="fas fa-check-circle text-success me-2"></i> Laravel & PHP Development</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> WordPress Theme/Plugin Customization & Elementor Expert</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> HTML, CSS, JavaScript, Bootstrap (Basics)</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> MySQL Database & REST API Integration</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> GitHub, Deployment & Basic SEO Knowledge</li>
          </ul>
        </div>
      </div>
    </div>
  </section><?php /**PATH C:\xampp\htdocs\laravel-portfolio-project\resources\views/pages/inc/about.blade.php ENDPATH**/ ?>