<!-- Hero Section -->
  <section class="hero" id="home" data-aos="fade-down">
    <div class="container">
      <h1 class="display-4">Hello, I'm Tafirul Islam</h1>
      <p class="lead">A Dedicated Teacher & Lifelong Learner</p>
    </div>
  </section><?php /**PATH C:\xampp\htdocs\Laravel-Tafirul- Portfolio\resources\views/pages/inc/hero.blade.php ENDPATH**/ ?>