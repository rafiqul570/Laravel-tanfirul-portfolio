
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
</head>
<body>

    <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
      <div class="d-flex justify-content-between">
        <h3 class="text-dark pb-3">Patient Infometion</h3>
      </div>
        
         <div class="">
           <h5>ID - <?php echo e($viewContact->id); ?></h5><br>
           <h5>NAME - <?php echo e($viewContact->name); ?></h5><br>
           <h5>EMAIL - <?php echo e($viewContact->email); ?></h5><br>
           <h5>SUBJECT - <?php echo e($viewContact->subject); ?></h5><br>
           <h5>MESSAGE - <?php echo e($viewContact->message); ?></h5><br>

         </div>
       </div>

    <script src="https://code.jquery.com/jquery-3.7.1.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

    <script>
    <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    <?php endif; ?>
    </script>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-appointment\resources\views/contact/view.blade.php ENDPATH**/ ?>